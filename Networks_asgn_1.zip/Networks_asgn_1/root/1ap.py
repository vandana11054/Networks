import socket
import struct
import threading
import time
import json
import random
import sys
import csv
import statistics
import matplotlib.pyplot as plt
import subprocess
import psutil # Used for monitoring server resources

# --- Configuration ---
SERVER_IP = "127.0.0.1"  # Changed to localhost for local testing
SERVER_PORT = 11054
CLIENT_CSV_FILE = "clients.csv"
SERVER_SOURCE_FILE = "1A_server.cpp"
SERVER_EXECUTABLE = "./server_executable"

# Concurrency levels to test automatically in one run.
# You can customize this list to change the test loads.
CLIENT_LOADS = [1, 2, 4, 6, 8,10] # Extended for more data points

# Protocol constants
KEEP_ALIVE_PING = "KEEP_ALIVE_PING"
KEEP_ALIVE_OK = "KEEP_ALIVE_OK"
TIMEOUT_S = 45.0

# --- MODIFIED: Server Resource Monitoring ---
def monitor_server_performance(process, stop_event, metrics_list):
    """
    Monitors the CPU and Memory usage of the server process in a separate thread.
    """
    try:
        while not stop_event.is_set():
            # Get CPU and Memory usage
            cpu_percent = process.cpu_percent(interval=1.0)
            # Get Resident Set Size (RSS) memory in Megabytes (MB)
            memory_mb = process.memory_info().rss / (1024 * 1024)
            
            metrics_list.append({'cpu': cpu_percent, 'memory_mb': memory_mb})
            
    except psutil.NoSuchProcess:
        print("Monitoring stopped: Server process not found.")
    except Exception as e:
        print(f"An error occurred in the monitoring thread: {e}")

# --- Network Functions (Unchanged) ---
def send_message(sock, message):
    """Encodes, packs, sends a message, and returns the number of bytes sent."""
    try:
        encoded_message = message.encode('utf-8')
        bytes_sent = 4 + len(encoded_message)
        packed_len = struct.pack('!I', len(encoded_message))
        sock.sendall(packed_len + encoded_message)
        return True, bytes_sent
    except (BrokenPipeError, ConnectionResetError, OSError):
        return False, 0

def receive_message(sock):
    """Receives a message and returns the message and number of bytes received."""
    total_bytes_received = 0
    while True:
        try:
            len_bytes = sock.recv(4)
            if not len_bytes: return None, total_bytes_received
            total_bytes_received += len(len_bytes)
            msg_len = struct.unpack('!I', len_bytes)[0]
            full_msg_bytes = b''
            while len(full_msg_bytes) < msg_len:
                chunk = sock.recv(msg_len - len(full_msg_bytes))
                if not chunk: return None, total_bytes_received
                full_msg_bytes += chunk
            total_bytes_received += len(full_msg_bytes)
            message = full_msg_bytes.decode('utf-8')
            if message == KEEP_ALIVE_PING:
                _, bytes_sent = send_message(sock, KEEP_ALIVE_OK)
                continue
            return message, total_bytes_received
        except (ConnectionResetError, BrokenPipeError, struct.error, OSError):
            return None, total_bytes_received
        except socket.timeout:
            return "SOCKET_TIMEOUT", total_bytes_received

# --- Client Simulation Logic (Unchanged) ---
def simulate_client(client_id, client_data, results_queue):
    metrics = {"generation_latency": 0, "answer_latencies": [], "quiz_bytes": 0, "quiz_duration": 0, "error": None}
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.settimeout(TIMEOUT_S)
            sock.connect((SERVER_IP, SERVER_PORT))
            send_message(sock, "PLAY")
            receive_message(sock)
            send_message(sock, client_data['username'])
            receive_message(sock)
            genre_send_time = time.perf_counter()
            send_message(sock, client_data['genre'])
            msg, _ = receive_message(sock)
            if msg is None or "SOCKET_TIMEOUT" in msg: raise ConnectionError("Timeout waiting for quiz start.")
            while not msg.strip().startswith('{'):
                 msg, _ = receive_message(sock)
                 if msg is None or "SOCKET_TIMEOUT" in msg: raise ConnectionError("Timeout before first question.")
            first_question_receive_time = time.perf_counter()
            metrics['generation_latency'] = first_question_receive_time - genre_send_time
            quiz_start_time = time.perf_counter()
            while True:
                if msg is None: break
                if msg.strip().startswith('{'):
                    answer_send_time = time.perf_counter()
                    answer = random.choice(['A', 'B', 'C', 'D'])
                    sent_ok, bytes_sent = send_message(sock, answer)
                    if not sent_ok: break
                    metrics['quiz_bytes'] += bytes_sent
                    response_msg, bytes_received = receive_message(sock)
                    if response_msg is None: break
                    response_receive_time = time.perf_counter()
                    metrics['quiz_bytes'] += bytes_received
                    metrics['answer_latencies'].append(response_receive_time - answer_send_time)
                elif "Quiz Complete" in msg or "LEADERBOARD" in msg:
                    break
                msg, bytes_received = receive_message(sock)
                metrics['quiz_bytes'] += bytes_received
            quiz_end_time = time.perf_counter()
            metrics['quiz_duration'] = quiz_end_time - quiz_start_time
        except (ConnectionError, ConnectionRefusedError) as e:
            metrics['error'] = str(e)
        except Exception as e:
            metrics['error'] = f"Unexpected error: {e}"
        results_queue.append(metrics)

# --- Main Execution Block ---
if __name__ == "__main__":
    # --- MODIFIED: Compile the C++ Server ---
    print("----- Compiling C++ Server -----")
    try:
        # The command to compile the server code. -pthread is needed for std::thread.
        compile_command = ["g++", SERVER_SOURCE_FILE, "-o", SERVER_EXECUTABLE, "-pthread"]
        subprocess.run(compile_command, check=True, capture_output=True, text=True)
        print(f"✅ Server compiled successfully as '{SERVER_EXECUTABLE}'")
    except FileNotFoundError:
        print("❌ Error: 'g++' compiler not found. Please install g++ and ensure it's in your PATH.")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: Server compilation failed with exit code {e.returncode}.")
        print("Compiler Output (stderr):\n" + e.stderr)
        sys.exit(1)

    # --- Load client configurations ---
    try:
        with open(CLIENT_CSV_FILE, mode='r', encoding='utf-8') as infile:
            client_configs = list(csv.DictReader(infile))
        if len(client_configs) < max(CLIENT_LOADS):
            raise FileNotFoundError(f"CSV file must contain at least {max(CLIENT_LOADS)} clients for the test.")
    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

    # --- MODIFIED: Start the Server and Monitor ---
    server_process = None
    try:
        print("\n----- Starting C++ Server Process -----")
        # Start the server as a background process, suppressing its output
        server_process = subprocess.Popen([SERVER_EXECUTABLE], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        # Give server a moment to initialize
        time.sleep(2) 
        
        # Check if server started correctly
        if server_process.poll() is not None:
            raise RuntimeError("Server process terminated unexpectedly after start.")
            
        print(f"✅ Server process started with PID: {server_process.pid}")
        psutil_process = psutil.Process(server_process.pid)
        
        # Send 'N' to the server's stdin to disable debug mode
        server_process.stdin.write(b'N\n')
        server_process.stdin.flush()

        # MODIFIED: Dictionary to store the final aggregated results for plotting
        final_results = {
            "clients": [], "avg_throughput": [], "avg_gen_latency": [], "avg_answer_latency": [],
            "avg_cpu": [], "max_cpu": [], "avg_mem": [], "max_mem": []
        }

        # Run the experiment for each concurrency level
        for num_clients in CLIENT_LOADS:
            print(f"\n----- Running test for {num_clients} concurrent client(s) -----")
            
            threads = []
            results_queue = []
            
            # MODIFIED: Start monitoring for this specific load test
            server_metrics = []
            stop_monitoring = threading.Event()
            monitor_thread = threading.Thread(
                target=monitor_server_performance,
                args=(psutil_process, stop_monitoring, server_metrics)
            )
            monitor_thread.start()

            # Start client threads
            for i in range(num_clients):
                thread = threading.Thread(
                    target=simulate_client,
                    args=(i + 1, client_configs[i], results_queue)
                )
                threads.append(thread)
                thread.start()
                time.sleep(0.05)

            for thread in threads:
                thread.join()

            # MODIFIED: Stop monitoring and collect data
            stop_monitoring.set()
            monitor_thread.join()

            # --- Aggregate and print results for this specific run ---
            successful_runs = [r for r in results_queue if r['error'] is None]
            
            if not successful_runs:
                print(f"  => All {num_clients} clients failed to complete the test.")
                # Add null/zero data to keep plots consistent
                for key in final_results: final_results[key].append(0 if key == "clients" else num_clients)
                continue
                
            total_throughput = sum(r['quiz_bytes'] / r['quiz_duration'] for r in successful_runs if r['quiz_duration'] > 0)
            total_gen_latency = sum(r['generation_latency'] for r in successful_runs)
            all_answer_latencies = [lat for r in successful_runs for lat in r['answer_latencies']]
                
            avg_throughput_kbps = (total_throughput / len(successful_runs)) / 1024 if successful_runs else 0
            avg_gen_latency = total_gen_latency / len(successful_runs) if successful_runs else 0
            avg_answer_latency = statistics.mean(all_answer_latencies) if all_answer_latencies else 0
            
            # MODIFIED: Aggregate server metrics
            avg_cpu = statistics.mean([m['cpu'] for m in server_metrics]) if server_metrics else 0
            max_cpu = max([m['cpu'] for m in server_metrics]) if server_metrics else 0
            avg_mem = statistics.mean([m['memory_mb'] for m in server_metrics]) if server_metrics else 0
            max_mem = max([m['memory_mb'] for m in server_metrics]) if server_metrics else 0

            print(f"  Client Metrics:")
            print(f"    - Average Generation Latency: {avg_gen_latency:.4f} s")
            print(f"    - Average Answer Latency:     {avg_answer_latency:.4f} s")
            print(f"    - Average Throughput:         {avg_throughput_kbps:.2f} KB/s")
            print(f"  Server Metrics:")
            print(f"    - Average CPU Usage:          {avg_cpu:.2f}%")
            print(f"    - Max CPU Usage:              {max_cpu:.2f}%")
            print(f"    - Average Memory Usage:       {avg_mem:.2f} MB")
            print(f"    - Max Memory Usage:           {max_mem:.2f} MB")
            
            # Store results for the final plot
            final_results["clients"].append(num_clients)
            final_results["avg_throughput"].append(avg_throughput_kbps)
            final_results["avg_gen_latency"].append(avg_gen_latency)
            final_results["avg_answer_latency"].append(avg_answer_latency)
            final_results["avg_cpu"].append(avg_cpu)
            final_results["max_cpu"].append(max_cpu)
            final_results["avg_mem"].append(avg_mem)
            final_results["max_mem"].append(max_mem)
            
    except (RuntimeError, psutil.NoSuchProcess) as e:
        print(f"\n❌ A critical error occurred: {e}")
    finally:
        # --- MODIFIED: Ensure server process is terminated ---
        if server_process and server_process.poll() is None:
            print("\n----- Stopping C++ Server Process -----")
            server_process.terminate()
            server_process.wait()
            print("✅ Server process terminated.")

    # --- MODIFIED: Plotting the results in a 2x2 grid ---
    print("\n----- All tests complete. Generating plots... -----")
    
    if not final_results["clients"]:
        print("No data was collected. Cannot generate plots.")
        sys.exit(0)

    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Server Performance Analysis Dashboard', fontsize=20, weight='bold')
    
    clients = final_results['clients']

    # Plot 1: Throughput
    axes[0, 0].plot(clients, final_results['avg_throughput'], marker='o', linestyle='-', color='b', label='Avg Throughput')
    axes[0, 0].set_title('Throughput vs. Concurrent Clients', fontsize=14)
    axes[0, 0].set_xlabel('Number of Concurrent Clients')
    axes[0, 0].set_ylabel('Average Throughput (KB/s)')
    axes[0, 0].grid(True, linestyle='--', alpha=0.6)
    axes[0, 0].set_xticks(CLIENT_LOADS)

    # Plot 2: Latency
    axes[0, 1].plot(clients, final_results['avg_gen_latency'], marker='s', linestyle='--', color='r', label='Quiz Generation Latency')
    axes[0, 1].plot(clients, final_results['avg_answer_latency'], marker='^', linestyle=':', color='g', label='Avg Answer Latency')
    axes[0, 1].set_title('Latency vs. Concurrent Clients', fontsize=14)
    axes[0, 1].set_xlabel('Number of Concurrent Clients')
    axes[0, 1].set_ylabel('Average Latency (seconds)')
    axes[0, 1].grid(True, linestyle='--', alpha=0.6)
    axes[0, 1].legend()
    axes[0, 1].set_xticks(CLIENT_LOADS)

    # Plot 3: CPU Usage
    axes[1, 0].plot(clients, final_results['avg_cpu'], marker='o', linestyle='-', color='purple', label='Average CPU %')
    axes[1, 0].plot(clients, final_results['max_cpu'], marker='x', linestyle='--', color='orange', label='Max CPU %')
    axes[1, 0].set_title('Server CPU Usage vs. Concurrent Clients', fontsize=14)
    axes[1, 0].set_xlabel('Number of Concurrent Clients')
    axes[1, 0].set_ylabel('CPU Usage (%)')
    axes[1, 0].grid(True, linestyle='--', alpha=0.6)
    axes[1, 0].legend()
    axes[1, 0].set_xticks(CLIENT_LOADS)
    
    # Plot 4: Memory Usage
    axes[1, 1].plot(clients, final_results['avg_mem'], marker='o', linestyle='-', color='teal', label='Average Memory (MB)')
    axes[1, 1].plot(clients, final_results['max_mem'], marker='x', linestyle='--', color='brown', label='Max Memory (MB)')
    axes[1, 1].set_title('Server Memory Usage vs. Concurrent Clients', fontsize=14)
    axes[1, 1].set_xlabel('Number of Concurrent Clients')
    axes[1, 1].set_ylabel('Memory Usage (MB)')
    axes[1, 1].grid(True, linestyle='--', alpha=0.6)
    axes[1, 1].legend()
    axes[1, 1].set_xticks(CLIENT_LOADS)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()