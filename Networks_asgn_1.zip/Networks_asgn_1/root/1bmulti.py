import socket
import struct
import threading
import time
import random
import csv

# --- Configuration ---
# IMPORTANT: Change this to the IP address where your C++ server is running.
SERVER_IP = "192.168.50.111"
SERVER_PORT = 11054
BUFFER_SIZE = 8192

# --- Protocol Constants ---
KEEP_ALIVE_PING = "KEEP_ALIVE"
KEEP_ALIVE_OK = "ALIVE_OK"

# --- Helper Functions for Custom Protocol (Unchanged) ---

def send_message(sock, message):
    """Encodes and sends a message with a 4-byte length prefix."""
    try:
        encoded_message = message.encode('utf-8')
        header = struct.pack('!I', len(encoded_message))
        sock.sendall(header + encoded_message)
    except (socket.error, BrokenPipeError):
        return False
    return True

def receive_message(sock):
    """Receives and decodes a message with a 4-byte length prefix."""
    try:
        header = sock.recv(4)
        if not header:
            return None
        
        msg_len = struct.unpack('!I', header)[0]
        
        data = b''
        while len(data) < msg_len:
            packet = sock.recv(min(msg_len - len(data), BUFFER_SIZE))
            if not packet:
                return None
            data += packet
            
        return data.decode('utf-8')
    except (socket.error, ConnectionResetError, struct.error):
        return None

# --- Main Simulation Logic for a Single Client ---

def simulate_client(client_id, username, genre):
    """A function that simulates a single client's session using provided data."""
    
    time.sleep(random.uniform(0.1, 0.5))
    
    print(f"[Client {client_id} - {username}] Starting session with genre '{genre}'...")

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((SERVER_IP, SERVER_PORT))
        print(f"[Client {client_id} - {username}] Connected to server.")

        send_message(sock, "PLAY")

        while True:
            server_msg = receive_message(sock)

            if server_msg is None:
                print(f"[Client {client_id} - {username}] Server closed the connection.")
                break

            if server_msg == KEEP_ALIVE_PING:
                send_message(sock, KEEP_ALIVE_OK)
                continue
            
            # NEW: Handle the cache source information message from the server
            elif server_msg.startswith("QUIZ_SOURCE:"):
                source = server_msg.split(":")[1]
                print(f"[Client {client_id} - {username}] ✅ Server indicates quiz source will be: {source}")
                # No action needed, just log it and continue listening
                continue

            elif "Enter your username" in server_msg:
                print(f"[Client {client_id} - {username}] Sending username.")
                send_message(sock, username)

            elif "Enter quiz genre" in server_msg:
                print(f"[Client {client_id} - {username}] Sending genre.")
                send_message(sock, genre)

            elif server_msg.strip().startswith('{') and '"question"' in server_msg:
                print(f"[Client {client_id} - {username}] Received a question. Answering randomly.")
                answer = random.choice(['A', 'B', 'C', 'D'])
                time.sleep(random.uniform(1.0, 3.0)) # Simulate "thinking" time
                send_message(sock, answer)

            elif "Quiz over" in server_msg or "Thanks for playing" in server_msg or "Server full" in server_msg:
                print(f"[Client {client_id} - {username}] Quiz finished. Disconnecting.")
                break
            
            else:
                 # This will catch other informational messages like "Generating quiz..."
                 # or the older "API:10" / "CACHE:10" messages.
                 print(f"[Client {client_id} - {username}] Server Info: {server_msg.strip().splitlines()[0]}")

    except ConnectionRefusedError:
        print(f"[Client {client_id} - {username}] Connection refused. Is the server running?")
    except Exception as e:
        print(f"[Client {client_id} - {username}] An error occurred: {e}")
    finally:
        sock.close()


# --- Main Execution ---

if __name__ == "__main__":
    
    client_profiles = []
    try:
        with open('clients.csv', mode='r', newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) == 2:
                    client_profiles.append({'username': row[0].strip(), 'genre': row[1].strip()})
    except FileNotFoundError:
        print("Error: 'clients.csv' not found. Please create it first.")
        exit()

    if not client_profiles:
        print("Error: 'clients.csv' is empty or invalid. No clients to simulate.")
        exit()

    print("--- Starting Cache-Aware Client Simulation ---")
    print(f"Target Server: {SERVER_IP}:{SERVER_PORT}")
    print(f"Number of Clients: {len(client_profiles)}")
    print("-" * 45)

    threads = []
    for i, profile in enumerate(client_profiles):
        thread = threading.Thread(
            target=simulate_client, 
            args=(i + 1, profile['username'], profile['genre'])
        )
        threads.append(thread)
        thread.start()
        # Stagger the start of clients slightly to make logs easier to read
        time.sleep(0.2)

    for thread in threads:
        thread.join()

    print("-" * 45)
    print("--- All client simulations have finished. ---")