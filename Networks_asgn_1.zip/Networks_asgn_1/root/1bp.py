import socket
import struct
import threading
import time
import json
import random
import sys
import csv
import statistics
import matplotlib.pyplot as plt
import subprocess
import psutil # Used for monitoring server resources
import os

# --- Configuration ---
SERVER_IP = "127.0.0.1"  # Changed to localhost for local testing
SERVER_PORT = 11054
CLIENT_CSV_FILE = "clients.csv"
SERVER_SOURCE_FILE = "1B_server.cpp"
SERVER_EXECUTABLE = "./server_executable"

# Concurrency levels to test automatically in one run.
CLIENT_LOADS = [1, 2, 4, 6, 8, 10] 

# Protocol constants
KEEP_ALIVE_PING = "KEEP_ALIVE_PING"
KEEP_ALIVE_OK = "KEEP_ALIVE_OK"
TIMEOUT_S = 60.0 # Increased timeout to account for potential long API waits

# --- MODIFIED: Create a suitable CSV for testing cache performance ---
def create_test_csv_if_not_exists(filename, num_records):
    """
    Creates a CSV file with repeating genres to ensure the cache is tested.
    """
    if os.path.exists(filename):
        print(f"✅ Using existing '{filename}' for client data.")
        return

    print(f"'{filename}' not found. Generating a new one for testing...")
    genres = ["science", "history", "sports", "technology", "movies", "geography"]
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['username', 'genre'])
        for i in range(num_records):
            username = f"User{i+1}"
            # Cycle through genres to ensure repeats for cache hits
            genre = genres[i % len(genres)]
            writer.writerow([username, genre])
    print(f"✅ Generated '{filename}' with {num_records} records.")


# --- Server Resource Monitoring (Unchanged) ---
def monitor_server_performance(process, stop_event, metrics_list):
    """Monitors the CPU and Memory usage of the server process."""
    try:
        while not stop_event.is_set():
            cpu_percent = process.cpu_percent(interval=1.0)
            memory_mb = process.memory_info().rss / (1024 * 1024)
            metrics_list.append({'cpu': cpu_percent, 'memory_mb': memory_mb})
    except psutil.NoSuchProcess:
        print("Monitoring stopped: Server process not found.")
    except Exception as e:
        print(f"An error occurred in the monitoring thread: {e}")

# --- Network Functions (Unchanged) ---
def send_message(sock, message):
    try:
        encoded_message = message.encode('utf-8')
        packed_len = struct.pack('!I', len(encoded_message))
        sock.sendall(packed_len + encoded_message)
        return True, 4 + len(encoded_message)
    except (BrokenPipeError, ConnectionResetError, OSError):
        return False, 0

def receive_message(sock):
    total_bytes_received = 0
    while True:
        try:
            len_bytes = sock.recv(4)
            if not len_bytes: return None, total_bytes_received
            total_bytes_received += len(len_bytes)
            msg_len = struct.unpack('!I', len_bytes)[0]
            full_msg_bytes = b''
            while len(full_msg_bytes) < msg_len:
                chunk = sock.recv(msg_len - len(full_msg_bytes))
                if not chunk: return None, total_bytes_received
                full_msg_bytes += chunk
            total_bytes_received += len(full_msg_bytes)
            message = full_msg_bytes.decode('utf-8')
            if message == KEEP_ALIVE_PING:
                send_message(sock, KEEP_ALIVE_OK)
                continue
            return message, total_bytes_received
        except (ConnectionResetError, BrokenPipeError, struct.error, OSError):
            return None, total_bytes_received
        except socket.timeout:
            return "SOCKET_TIMEOUT", total_bytes_received

# --- MODIFIED: Client Simulation Logic (Now Cache-Aware) ---
def simulate_client(client_id, client_data, results_queue):
    """
    Simulates a single client session and now detects if the quiz was served from cache.
    """
    metrics = {
        "generation_latency": 0, "answer_latencies": [], "quiz_bytes": 0, 
        "quiz_duration": 0, "error": None, "was_cache_hit": False
    }
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.settimeout(TIMEOUT_S)
            sock.connect((SERVER_IP, SERVER_PORT))
            send_message(sock, "PLAY")
            receive_message(sock) # "Enter your username:"
            send_message(sock, client_data['username'])
            receive_message(sock) # "Enter quiz genre:"
            
            genre_send_time = time.perf_counter()
            send_message(sock, client_data['genre'])
            
            # MODIFIED: Listen for QUIZ_SOURCE and the first question
            first_question_msg = None
            while True:
                msg, _ = receive_message(sock)
                if msg is None or "SOCKET_TIMEOUT" in msg:
                    raise ConnectionError("Timeout waiting for quiz start.")
                
                # Check for our new cache-aware message from the server
                if "QUIZ_SOURCE:CACHE" in msg:
                    metrics['was_cache_hit'] = True
                
                # The first JSON message is the start of the quiz
                if msg.strip().startswith('{'):
                    first_question_msg = msg
                    break # Exit loop and proceed with the quiz
            
            first_question_receive_time = time.perf_counter()
            metrics['generation_latency'] = first_question_receive_time - genre_send_time
            
            quiz_start_time = time.perf_counter()
            msg = first_question_msg # Start with the question we already received
            while True:
                if msg is None: break
                if msg.strip().startswith('{'):
                    answer_send_time = time.perf_counter()
                    answer = random.choice(['A', 'B', 'C', 'D'])
                    sent_ok, bytes_sent = send_message(sock, answer)
                    if not sent_ok: break
                    metrics['quiz_bytes'] += bytes_sent
                    
                    response_msg, bytes_received = receive_message(sock) # Correct/Wrong
                    if response_msg is None: break
                    response_receive_time = time.perf_counter()
                    metrics['quiz_bytes'] += bytes_received
                    metrics['answer_latencies'].append(response_receive_time - answer_send_time)
                
                elif "Quiz Complete" in msg or "LEADERBOARD" in msg:
                    break
                
                msg, bytes_received = receive_message(sock) # Next question or end message
                metrics['quiz_bytes'] += bytes_received

            quiz_end_time = time.perf_counter()
            metrics['quiz_duration'] = quiz_end_time - quiz_start_time
        except (ConnectionError, ConnectionRefusedError) as e:
            metrics['error'] = str(e)
        except Exception as e:
            metrics['error'] = f"Unexpected error in client {client_id}: {e}"
        results_queue.append(metrics)

# --- Main Execution Block ---
if __name__ == "__main__":
    # --- Compile the C++ Server ---
    print("----- Compiling C++ Server -----")
    try:
        compile_command = ["g++", SERVER_SOURCE_FILE, "-o", SERVER_EXECUTABLE, "-pthread", "-std=c++11"]
        subprocess.run(compile_command, check=True, capture_output=True, text=True)
        print(f"✅ Server compiled successfully as '{SERVER_EXECUTABLE}'")
    except FileNotFoundError:
        print("❌ Error: 'g++' compiler not found. Please install g++ and ensure it's in your PATH.")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: Server compilation failed.\n   Stderr: {e.stderr}")
        sys.exit(1)

    # --- Generate CSV if needed and load client configs ---
    max_load = max(CLIENT_LOADS)
    create_test_csv_if_not_exists(CLIENT_CSV_FILE, max_load)
    try:
        with open(CLIENT_CSV_FILE, mode='r', encoding='utf-8') as infile:
            client_configs = list(csv.DictReader(infile))
        if len(client_configs) < max_load:
            raise RuntimeError(f"CSV file must contain at least {max_load} clients for the test.")
    except (FileNotFoundError, RuntimeError) as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

    # --- Start the Server and Monitor ---
    server_process = None
    try:
        print("\n----- Starting C++ Server Process -----")
        server_process = subprocess.Popen([SERVER_EXECUTABLE], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(2)
        if server_process.poll() is not None:
            raise RuntimeError("Server process terminated unexpectedly after start.")
        print(f"✅ Server process started with PID: {server_process.pid}")
        psutil_process = psutil.Process(server_process.pid)
        server_process.stdin.write(b'n\n') # Use lowercase 'n' for the new prompt
        server_process.stdin.flush()

        # MODIFIED: Dictionary now includes cache hit ratio
        final_results = {
            "clients": [], "avg_throughput": [], "avg_gen_latency": [], "avg_answer_latency": [],
            "avg_cpu": [], "max_cpu": [], "avg_mem": [], "max_mem": [], "cache_hit_ratio": []
        }

        # Run the experiment for each concurrency level
        for num_clients in CLIENT_LOADS:
            print(f"\n----- Running test for {num_clients} concurrent client(s) -----")
            
            threads, results_queue, server_metrics = [], [], []
            stop_monitoring = threading.Event()
            monitor_thread = threading.Thread(target=monitor_server_performance, args=(psutil_process, stop_monitoring, server_metrics))
            monitor_thread.start()

            for i in range(num_clients):
                thread = threading.Thread(target=simulate_client, args=(i + 1, client_configs[i], results_queue))
                threads.append(thread)
                thread.start()
                time.sleep(0.05)

            for thread in threads:
                thread.join()

            stop_monitoring.set()
            monitor_thread.join()

            successful_runs = [r for r in results_queue if r['error'] is None]
            if not successful_runs:
                print(f"  => All {num_clients} clients failed to complete the test.")
                for key in final_results: final_results[key].append(num_clients if key == "clients" else 0)
                continue
                
            # Aggregate client metrics
            avg_throughput_kbps = (sum(r['quiz_bytes'] / r['quiz_duration'] for r in successful_runs if r['quiz_duration'] > 0) / len(successful_runs)) / 1024
            avg_gen_latency = statistics.mean(r['generation_latency'] for r in successful_runs)
            all_answer_latencies = [lat for r in successful_runs for lat in r['answer_latencies']]
            avg_answer_latency = statistics.mean(all_answer_latencies) if all_answer_latencies else 0
            
            # MODIFIED: Aggregate cache hits
            cache_hits = sum(1 for r in successful_runs if r['was_cache_hit'])
            cache_hit_ratio = (cache_hits / len(successful_runs)) * 100 if successful_runs else 0
            
            # Aggregate server metrics
            avg_cpu = statistics.mean([m['cpu'] for m in server_metrics]) if server_metrics else 0
            max_cpu = max([m['cpu'] for m in server_metrics]) if server_metrics else 0
            avg_mem = statistics.mean([m['memory_mb'] for m in server_metrics]) if server_metrics else 0
            max_mem = max([m['memory_mb'] for m in server_metrics]) if server_metrics else 0

            # Print results for this run
            print(f"  Client & Cache Metrics:")
            print(f"    - Cache Hit Ratio:            {cache_hit_ratio:.2f}% ({cache_hits}/{len(successful_runs)})")
            print(f"    - Average Generation Latency: {avg_gen_latency:.4f} s")
            print(f"    - Average Answer Latency:     {avg_answer_latency:.4f} s")
            print(f"    - Average Throughput:         {avg_throughput_kbps:.2f} KB/s")
            print(f"  Server Metrics:")
            print(f"    - Average CPU Usage:          {avg_cpu:.2f}%")
            print(f"    - Max CPU Usage:              {max_cpu:.2f}%")
            print(f"    - Average Memory Usage:       {avg_mem:.2f} MB")
            
            # Store results for the final plot
            final_results["clients"].append(num_clients)
            final_results["avg_throughput"].append(avg_throughput_kbps)
            final_results["avg_gen_latency"].append(avg_gen_latency)
            final_results["avg_answer_latency"].append(avg_answer_latency)
            final_results["cache_hit_ratio"].append(cache_hit_ratio)
            final_results["avg_cpu"].append(avg_cpu)
            final_results["max_cpu"].append(max_cpu)
            final_results["avg_mem"].append(avg_mem)
            final_results["max_mem"].append(max_mem)
            
    except (RuntimeError, psutil.NoSuchProcess) as e:
        print(f"\n❌ A critical error occurred: {e}")
    finally:
        if server_process and server_process.poll() is None:
            print("\n----- Stopping C++ Server Process -----")
            server_process.terminate()
            server_process.wait()
            print("✅ Server process terminated.")

    # --- MODIFIED: Plotting now includes cache hit ratio ---
    print("\n----- All tests complete. Generating plots... -----")
    
    if not final_results["clients"]:
        print("No data collected. Cannot generate plots.")
        sys.exit(0)

    fig, axes = plt.subplots(2, 2, figsize=(18, 13))
    fig.suptitle('Server Performance Analysis Dashboard (Cache-Enabled)', fontsize=20, weight='bold')
    clients = final_results['clients']

    # Plot 1: Throughput
    axes[0, 0].plot(clients, final_results['avg_throughput'], marker='o', linestyle='-', color='b')
    axes[0, 0].set_title('Throughput vs. Concurrent Clients', fontsize=14)
    axes[0, 0].set_xlabel('Number of Concurrent Clients')
    axes[0, 0].set_ylabel('Average Throughput (KB/s)')
    axes[0, 0].grid(True, linestyle='--', alpha=0.6)
    axes[0, 0].set_xticks(clients)

    # Plot 2: Latency AND Cache Hit Ratio
    ax_lat = axes[0, 1]
    ax_lat.plot(clients, final_results['avg_gen_latency'], marker='s', linestyle='--', color='r', label='Quiz Generation Latency')
    ax_lat.plot(clients, final_results['avg_answer_latency'], marker='^', linestyle=':', color='g', label='Avg Answer Latency')
    ax_lat.set_title('Latency & Cache Performance vs. Clients', fontsize=14)
    ax_lat.set_xlabel('Number of Concurrent Clients')
    ax_lat.set_ylabel('Average Latency (seconds)', color='black')
    ax_lat.grid(True, linestyle='--', alpha=0.6)
    ax_lat.set_xticks(clients)
    
    # Create a secondary Y-axis for the cache hit ratio
    ax_cache = ax_lat.twinx()
    ax_cache.plot(clients, final_results['cache_hit_ratio'], marker='P', linestyle='-.', color='darkorange', label='Cache Hit Ratio (%)')
    ax_cache.set_ylabel('Cache Hit Ratio (%)', color='darkorange')
    ax_cache.tick_params(axis='y', labelcolor='darkorange')
    ax_cache.set_ylim(0, 105)

    # Combine legends from both axes
    lines, labels = ax_lat.get_legend_handles_labels()
    lines2, labels2 = ax_cache.get_legend_handles_labels()
    ax_lat.legend(lines + lines2, labels + labels2, loc='best')

    # Plot 3: CPU Usage
    axes[1, 0].plot(clients, final_results['avg_cpu'], marker='o', linestyle='-', color='purple', label='Average CPU %')
    axes[1, 0].plot(clients, final_results['max_cpu'], marker='x', linestyle='--', color='deeppink', label='Max CPU %')
    axes[1, 0].set_title('Server CPU Usage vs. Concurrent Clients', fontsize=14)
    axes[1, 0].set_xlabel('Number of Concurrent Clients')
    axes[1, 0].set_ylabel('CPU Usage (%)')
    axes[1, 0].grid(True, linestyle='--', alpha=0.6)
    axes[1, 0].legend()
    axes[1, 0].set_xticks(clients)
    
    # Plot 4: Memory Usage
    axes[1, 1].plot(clients, final_results['avg_mem'], marker='o', linestyle='-', color='teal', label='Average Memory (MB)')
    axes[1, 1].plot(clients, final_results['max_mem'], marker='x', linestyle='--', color='sienna', label='Max Memory (MB)')
    axes[1, 1].set_title('Server Memory Usage vs. Concurrent Clients', fontsize=14)
    axes[1, 1].set_xlabel('Number of Concurrent Clients')
    axes[1, 1].set_ylabel('Memory Usage (MB)')
    axes[1, 1].grid(True, linestyle='--', alpha=0.6)
    axes[1, 1].legend()
    axes[1, 1].set_xticks(clients)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()