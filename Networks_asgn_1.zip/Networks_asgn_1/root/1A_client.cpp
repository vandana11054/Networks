#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <thread>
#include <atomic>
#include <mutex>
#include <chrono>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "json.hpp"

using namespace std;
using json = nlohmann::json;

// Configuration
const int PORT = 11054;
const int BUFFER_SIZE = 8192;

// Keep-alive constants matching server requirements
const string KEEP_ALIVE_PING = "KEEP_ALIVE";
const string KEEP_ALIVE_OK = "ALIVE_OK";

// Global state
atomic<bool> connection_active(false);
atomic<bool> debug_mode(false);

// Function declarations
bool send_message(int sock, const string& msg);
bool receive_message(int sock, string& msg);
void network_listener(int sock, vector<string>& msg_queue, mutex& q_mutex);
string trim_whitespace(const string& str);

// Network communication functions
bool send_message(int sock, const string& msg) {
    uint32_t len = msg.length();
    uint32_t network_len = htonl(len);
    if (send(sock, &network_len, sizeof(network_len), MSG_NOSIGNAL) < 0) return false;
    if (send(sock, msg.c_str(), len, MSG_NOSIGNAL) < 0) return false;
    if (debug_mode) cout << "[DEBUG] Sent: " << msg.substr(0, 30) << "..." << endl;
    return true;
}

bool receive_message(int sock, string& msg) {
    uint32_t network_len;
    int bytes_read = recv(sock, &network_len, sizeof(network_len), 0);
    if (bytes_read <= 0) return false;
    if (bytes_read != sizeof(network_len)) return false;

    uint32_t len = ntohl(network_len);
    if (len > BUFFER_SIZE) return false;
    
    char buffer[BUFFER_SIZE] = {0};
    size_t total_bytes_read = 0;
    while (total_bytes_read < len) {
        bytes_read = recv(sock, buffer + total_bytes_read, len - total_bytes_read, 0);
        if (bytes_read <= 0) return false;
        total_bytes_read += bytes_read;
    }
    msg.assign(buffer, len);
    if (debug_mode) cout << "[DEBUG] Received: " << msg.substr(0, 50) << "..." << endl;
    return true;
}

// Utility functions
string trim_whitespace(const string& str) {
    size_t start = str.find_first_not_of(" \t\n\r");
    if (start == string::npos) return "";
    size_t end = str.find_last_not_of(" \t\n\r");
    return str.substr(start, end - start + 1);
}

// Network listener with proper keep-alive protocol
void network_listener(int sock, vector<string>& msg_queue, mutex& q_mutex) {
    auto last_server_activity = chrono::steady_clock::now();
    const int SERVER_TIMEOUT = 90; // Allow longer timeout for quiz generation and completion
    
    while (connection_active) {
        string server_msg;
        if (!receive_message(sock, server_msg)) {
            if (debug_mode) cout << "[DEBUG] Network listener - connection lost" << endl;
            connection_active = false;
            break;
        }

        // Update last activity time
        last_server_activity = chrono::steady_clock::now();

        // Handle keep-alive with correct protocol messages
        if (server_msg == KEEP_ALIVE_PING) {
            if (debug_mode) cout << "[DEBUG] Received " << KEEP_ALIVE_PING << ", responding with " << KEEP_ALIVE_OK << endl;
            if (!send_message(sock, KEEP_ALIVE_OK)) {
                if (debug_mode) cout << "[DEBUG] Failed to respond to keep-alive" << endl;
                connection_active = false;
                break;
            }
        } else {
            lock_guard<mutex> guard(q_mutex);
            msg_queue.push_back(server_msg);
            if (debug_mode) cout << "[DEBUG] Added message to queue (size: " << msg_queue.size() << ")" << endl;
        }

        // Check for server timeout
        auto now = chrono::steady_clock::now();
        auto time_since_activity = chrono::duration_cast<chrono::seconds>(now - last_server_activity).count();
        
        if (time_since_activity >= SERVER_TIMEOUT) {
            if (debug_mode) cout << "[DEBUG] Server timeout after " << time_since_activity << " seconds" << endl;
            connection_active = false;
            break;
        }
    }
    if (debug_mode) cout << "[DEBUG] Network listener thread ending" << endl;
}

// Main function
int main() {
    cout << "Quiz Game Client" << endl;
    // cout << "Features:" << endl;
    // cout << "- Custom keep-alive protocol: KEEP_ALIVE <-> ALIVE_OK" << endl;
    // cout << "- CLI-based interface for quiz interaction" << endl;
    // cout << "- Genre selection and real-time question streaming" << endl;
    // cout << "- Real-time leaderboard viewing for connected clients" << endl;
    // cout << "- Support for timed quiz sessions (5-minute limit)" << endl;
    // cout << "- Connection management and automatic session handling" << endl;
    cout << "\nEnter 'debug' to enable debug mode, or press Enter to continue: ";
    
    string debug_input;
    getline(cin, debug_input);
    if (debug_input == "debug") {
        debug_mode = true;
        cout << "Debug mode enabled.\n" << endl;
    }

    while (true) {
        cout << "\n" << string(60, '=') << endl;
        cout << "                QUIZ GAME CLIENT" << endl;
        cout << string(60, '=') << endl;
        cout << "CLI-based Quiz Interface with Real-time Features" << endl;
        cout << string(60, '-') << endl;
        cout << "1. Play Quiz (Connect and select genre)" << endl;
        cout << "2. View Leaderboard (Request scores from server)" << endl;
        cout << "3. Exit" << endl;
        cout << string(60, '=') << endl;
        cout << "Enter your choice [1-3]: ";

        string choice;
        getline(cin, choice);
        choice = trim_whitespace(choice);

        if (choice == "1" || choice == "2") {
            int sock = 0;
            struct sockaddr_in serv_addr;
            
            if (debug_mode) cout << "[DEBUG] Creating socket for connection..." << endl;
            if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
                cerr << "Error: Could not create socket" << endl; 
                continue; 
            }
            
            serv_addr.sin_family = AF_INET;
            serv_addr.sin_port = htons(PORT);
            
            // Server IP - adjust as needed for your setup
            const char* server_ip = "192.168.50.111";  // Change this to your server's IP
            if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) { 
                cerr << "Error: Invalid server address" << endl; 
                close(sock); 
                continue; 
            }
            
            cout << "\nEstablishing connection to " << server_ip << ":" << PORT << "..." << endl;
            if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) { 
                cerr << "Error: Could not connect to server." << endl;
                cerr << "Please ensure the server is running and accessible." << endl;
                close(sock); 
                continue; 
            }

            cout << "Connection established successfully!" << endl;
            if (debug_mode) cout << "[DEBUG] Connected to server" << endl;

            connection_active = true;
            vector<string> msg_queue;
            mutex q_mutex;
            thread listener_thread(network_listener, sock, ref(msg_queue), ref(q_mutex));

            // Send command to server
            if (choice == "1") {
                if (debug_mode) cout << "[DEBUG] Sending PLAY command" << endl;
                send_message(sock, "PLAY");
                cout << "\nInitiating quiz session..." << endl;
                cout << "Note: Server will stream questions to you in real-time." << endl;
                cout << "Time limit: 5 minutes once quiz starts." << endl;
            } else {
                if (debug_mode) cout << "[DEBUG] Sending VIEW command" << endl;
                send_message(sock, "VIEW");
                cout << "\nRequesting leaderboard from server..." << endl;
            }
            
            bool waiting_for_input = false;
            bool quiz_active = false;
            int question_count = 0;
            auto last_message_time = chrono::steady_clock::now();
            const int MESSAGE_TIMEOUT = 120; // Extended timeout for quiz sessions
            
            // Main CLI message processing loop
            while (connection_active) {
                string msg_to_process;
                bool has_message = false;
                
                {
                    lock_guard<mutex> guard(q_mutex);
                    if (!msg_queue.empty()) {
                        msg_to_process = msg_queue.front();
                        msg_queue.erase(msg_queue.begin());
                        has_message = true;
                        last_message_time = chrono::steady_clock::now();
                    }
                }

                if (has_message) {
                    if (debug_mode) {
                        cout << "[DEBUG] Processing: " << msg_to_process.substr(0, 50) << "..." << endl;
                    }
                    
                    // Handle server full message
                    if (msg_to_process.find("Server full") != string::npos) {
                        cout << "\n" << string(50, '!') << endl;
                        cout << msg_to_process << endl;
                        cout << string(50, '!') << endl;
                        connection_active = false;
                        break;
                    }
                    
                    // Handle quiz session started message
                    if (msg_to_process.find("Quiz Session Started") != string::npos) {
                        cout << "\n" << string(50, '*') << endl;
                        cout << msg_to_process << endl;
                        cout << string(50, '*') << endl;
                        continue;
                    }
                    
                    // Handle timer-related messages
                    if (msg_to_process.find("TIME'S UP") != string::npos) {
                        cout << "\n" << string(50, '!') << endl;
                        cout << "TIME EXPIRED! Quiz session ended by server." << endl;
                        cout << string(50, '!') << endl;
                        cout << msg_to_process << endl;
                        // Session will end naturally
                        continue;
                    }
                    
                    // Parse quiz source information
                    if (msg_to_process.find("API:") == 0) {
                        quiz_active = true;
                        question_count = 0;
                        size_t colon_pos = msg_to_process.find(':');
                        if (colon_pos != string::npos) {
                            string count_str = msg_to_process.substr(colon_pos + 1);
                            cout << "\n" << string(50, '-') << endl;
                            cout << "Quiz ready! Questions generated from LLM API." << endl;
                            cout << "Total questions: " << count_str << endl;
                            cout << "Server will stream questions to you now..." << endl;
                            cout << "You have 5 minutes to complete all questions." << endl;
                            cout << string(50, '-') << endl;
                        }
                        continue;
                    }
                    
                    // Handle streamed questions (JSON format)
                    if (msg_to_process.front() == '{' && msg_to_process.find("question") != string::npos) {
                        try {
                            json q_data = json::parse(msg_to_process);
                            question_count++;
                            
                            cout << "\n" << string(70, '=') << endl;
                            cout << "QUESTION " << question_count << " (Streamed from Server)" << endl;
                            cout << string(70, '=') << endl;
                            cout << q_data["question"].get<string>() << endl;
                            cout << string(70, '-') << endl;
                            
                            auto options = q_data["options"];
                            for (const auto& option : options) { 
                                cout << option.get<string>() << endl; 
                            }
                            cout << string(70, '=') << endl;
                            cout << "Your answer [A/B/C/D]: ";
                            waiting_for_input = true;
                            
                        } catch (const exception& e) { 
                            cout << "Error: Could not parse question from server." << endl;
                            if (debug_mode) {
                                cout << "[DEBUG] Parse error: " << e.what() << endl;
                                cout << "[DEBUG] Raw data: " << msg_to_process << endl;
                            }
                        }
                    }
                    // Handle server text messages
                    else {
                        // CLI Interface - Handle different server prompts
                        if (msg_to_process.find("Enter your username") != string::npos) {
                            cout << "\n" << string(50, '-') << endl;
                            cout << "SERVER: " << msg_to_process << endl;
                            cout << string(50, '-') << endl;
                            cout << "Username: ";
                            waiting_for_input = true;
                        } else if (msg_to_process.find("Enter quiz genre") != string::npos) {
                            cout << "\n" << string(50, '-') << endl;
                            cout << "SERVER: " << msg_to_process << endl;
                            cout << "Available genres: science, history, sports, technology, literature, geography, etc." << endl;
                            cout << string(50, '-') << endl;
                            cout << "Select genre: ";
                            waiting_for_input = true;
                        } else if (msg_to_process.find("Generating quiz") != string::npos) {
                            cout << "\n" << string(50, '*') << endl;
                            cout << msg_to_process << endl;
                            cout << "This may take a few moments while the LLM generates questions..." << endl;
                            cout << string(50, '*') << endl;
                        } else if (msg_to_process.find("Correct!") != string::npos) {
                            cout << "\n✓ " << msg_to_process << " Well done!" << endl << endl;
                        } else if (msg_to_process.find("Wrong!") != string::npos) {
                            cout << "\n✗ " << msg_to_process << endl << endl;
                        } else {
                            cout << msg_to_process << endl;
                        }
                        
                        // Check for session end conditions
                        if (msg_to_process.find("LEADERBOARD") != string::npos ||
                            msg_to_process.find("Quiz over - final scores available") != string::npos ||
                            msg_to_process.find("Thanks for playing") != string::npos ||
                            msg_to_process.find("Connection will close") != string::npos ||
                            msg_to_process.find("Press Enter to return to menu") != string::npos ||
                            msg_to_process.find("Error:") != string::npos) {
                            
                            // Allow time for any remaining messages
                            this_thread::sleep_for(chrono::milliseconds(500));
                            
                            // Process any remaining messages in queue
                            {
                                lock_guard<mutex> guard(q_mutex);
                                while (!msg_queue.empty()) {
                                    cout << msg_queue.front() << endl;
                                    msg_queue.erase(msg_queue.begin());
                                }
                            }
                            
                            if (debug_mode) cout << "[DEBUG] Session end detected" << endl;
                            connection_active = false;
                            break;
                        }
                    }
                    
                    // CLI Input Handling
                    if (waiting_for_input) {
                        string user_input;
                        getline(cin, user_input);
                        user_input = trim_whitespace(user_input);
                        
                        if (!connection_active) {
                            if (debug_mode) cout << "[DEBUG] Connection lost during input" << endl;
                            break;
                        }
                        
                        if (debug_mode) cout << "[DEBUG] Sending user input: " << user_input << endl;
                        
                        if (!send_message(sock, user_input)) {
                            cout << "Error: Failed to send response to server" << endl;
                            connection_active = false;
                            break;
                        }
                        
                        waiting_for_input = false;
                        
                        // Show feedback for quiz answers
                        if (quiz_active && user_input.length() == 1 && 
                            (toupper(user_input[0]) >= 'A' && toupper(user_input[0]) <= 'D')) {
                            cout << "Answer sent to server. Waiting for evaluation..." << endl;
                        }
                    }
                } else {
                    // No messages - brief pause
                    this_thread::sleep_for(chrono::milliseconds(100));
                    
                    // Check for message timeout
                    auto now = chrono::steady_clock::now();
                    auto time_since_message = chrono::duration_cast<chrono::seconds>(now - last_message_time).count();
                    
                    if (time_since_message > MESSAGE_TIMEOUT && connection_active && !waiting_for_input) {
                        if (debug_mode) cout << "[DEBUG] Message timeout - no server response" << endl;
                        cout << "No response from server. Connection may have been lost." << endl;
                        connection_active = false;
                    }
                }
            }

            if (debug_mode) cout << "[DEBUG] Waiting for network listener to finish..." << endl;
            if (listener_thread.joinable()) {
                listener_thread.join();
            }
            close(sock);
            if (debug_mode) cout << "[DEBUG] Connection closed" << endl;
            
            // CLI pause before returning to menu
            cout << "\nConnection ended." << endl;
            if (choice == "2") {
                cout << "Press Enter to return to main menu...";
                cin.get();
            } else {
                cout << "Returning to main menu in 2 seconds..." << endl;
                this_thread::sleep_for(chrono::milliseconds(2000));
            }

        } else if (choice == "3") {
            cout << "\nExiting Quiz Game Client. Goodbye!" << endl;
            break;
        } else {
            cout << "Invalid choice. Please enter 1, 2, or 3." << endl;
        }
    }
    return 0;
}