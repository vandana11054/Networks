import argparse
from scapy.all import rdpcap, TCP
import sys
import os

def analyze_retransmissions(pcap_file):
    """Reads a pcap file and counts TCP retransmissions."""
    try:
        packets = rdpcap(pcap_file)
    except FileNotFoundError:
        print(f"Error: File '{pcap_file}' not found.", file=sys.stderr)
        return
    except Exception as e:
        print(f"Error reading pcap file: {e}", file=sys.stderr)
        return
        
    tcp_packets = [p for p in packets if p.haslayer(TCP)]
    
    # Scapy's retransmission detection is complex. A simple heuristic is to
    # track sequence numbers and see if they are resent.
    # Key: (src_ip, sport, dst_ip, dport) -> Value: set of sequence numbers seen
    streams = {}
    retransmissions = 0

    for pkt in tcp_packets:
        src_ip = pkt[0][1].src
        dst_ip = pkt[0][1].dst
        sport = pkt[0][2].sport
        dport = pkt[0][2].dport
        seq = pkt[0][2].seq
        
        # We only care about data packets
        payload_len = len(pkt[0][2].payload)
        if payload_len == 0:
            continue

        # Create a unique key for the stream (and its reverse)
        stream_key = tuple(sorted(((src_ip, sport), (dst_ip, dport))))

        if stream_key not in streams:
            streams[stream_key] = set()

        # If we've seen this sequence number before in this stream, it's a retransmission
        if seq in streams[stream_key]:
            retransmissions += 1
        else:
            streams[stream_key].add(seq)

    print(f"--- PCAP Analysis Summary for '{pcap_file}' ---")
    print(f"Total TCP packets: {len(tcp_packets)}")
    print(f"Detected TCP Retransmissions: {retransmissions}")
    if retransmissions > 0:
        print("Note: Retransmissions are strong indicators of packet loss and/or network congestion leading to timeouts.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze a pcap file for TCP retransmissions.")
    parser.add_argument('-f', '--file', type=str, required=True, help="Path to the .pcap file to analyze.")
    args = parser.parse_args()
    
    # Scapy often requires root privileges to run properly
    if sys.platform != 'win32' and os.geteuid() != 0:
        print("Warning: This script may need to be run with sudo for full functionality.", file=sys.stderr)

    analyze_retransmissions(args.file)