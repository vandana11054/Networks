#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <thread>
#include <atomic>
#include <mutex>
#include <chrono>
#include <random>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "json.hpp"

using namespace std;
using json = nlohmann::json;

// Configuration
const int PORT = 11054;
const int BUFFER_SIZE = 8192;

// Keep-alive constants matching server requirements
const string KEEP_ALIVE_PING = "KEEP_ALIVE";
const string KEEP_ALIVE_OK = "ALIVE_OK";

// Global state
atomic<bool> connection_active(false);
atomic<bool> debug_mode(false);
atomic<bool> auto_mode(false);

// Function declarations
bool send_message(int sock, const string& msg);
bool receive_message(int sock, string& msg);
void network_listener(int sock, vector<string>& msg_queue, mutex& q_mutex);
string trim_whitespace(const string& str);
string get_random_genre();
string get_random_username();
char get_random_answer();

// Network communication functions
bool send_message(int sock, const string& msg) {
    uint32_t len = msg.length();
    uint32_t network_len = htonl(len);
    if (send(sock, &network_len, sizeof(network_len), MSG_NOSIGNAL) < 0) return false;
    if (send(sock, msg.c_str(), len, MSG_NOSIGNAL) < 0) return false;
    if (debug_mode) cout << "[DEBUG] Sent: " << msg.substr(0, 30) << "..." << endl;
    return true;
}

bool receive_message(int sock, string& msg) {
    uint32_t network_len;
    int bytes_read = recv(sock, &network_len, sizeof(network_len), 0);
    if (bytes_read <= 0) return false;
    if (bytes_read != sizeof(network_len)) return false;

    uint32_t len = ntohl(network_len);
    if (len > BUFFER_SIZE) return false;
    
    char buffer[BUFFER_SIZE] = {0};
    size_t total_bytes_read = 0;
    while (total_bytes_read < len) {
        bytes_read = recv(sock, buffer + total_bytes_read, len - total_bytes_read, 0);
        if (bytes_read <= 0) return false;
        total_bytes_read += bytes_read;
    }
    msg.assign(buffer, len);
    if (debug_mode) cout << "[DEBUG] Received: " << msg.substr(0, 50) << "..." << endl;
    return true;
}

// Utility functions
string trim_whitespace(const string& str) {
    size_t start = str.find_first_not_of(" \t\n\r");
    if (start == string::npos) return "";
    size_t end = str.find_last_not_of(" \t\n\r");
    return str.substr(start, end - start + 1);
}

// Random generators for automatic testing
string get_random_username() {
    static random_device rd;
    static mt19937 gen(rd());
    vector<string> names = {"Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Henry", 
                           "Iris", "Jack", "Kate", "Liam", "Mia", "Noah", "Olivia", "Paul"};
    uniform_int_distribution<> dis(0, names.size() - 1);
    return names[dis(gen)] + to_string(gen() % 1000);
}

string get_random_genre() {
    static random_device rd;
    static mt19937 gen(rd());
    vector<string> genres = {"science", "history", "sports", "technology", "literature", 
                            "geography", "movies", "music", "art", "mathematics", "biology", "physics"};
    uniform_int_distribution<> dis(0, genres.size() - 1);
    return genres[dis(gen)];
}

char get_random_answer() {
    static random_device rd;
    static mt19937 gen(rd());
    vector<char> answers = {'A', 'B', 'C', 'D'};
    uniform_int_distribution<> dis(0, 3);
    return answers[dis(gen)];
}

// Network listener with proper keep-alive protocol
void network_listener(int sock, vector<string>& msg_queue, mutex& q_mutex) {
    auto last_server_activity = chrono::steady_clock::now();
    const int SERVER_TIMEOUT = 120; // Extended timeout for cache/API operations
    
    while (connection_active) {
        string server_msg;
        if (!receive_message(sock, server_msg)) {
            if (debug_mode) cout << "[DEBUG] Network listener - connection lost" << endl;
            connection_active = false;
            break;
        }

        // Update last activity time
        last_server_activity = chrono::steady_clock::now();

        // Handle keep-alive with correct protocol messages
        if (server_msg == KEEP_ALIVE_PING) {
            if (debug_mode) cout << "[DEBUG] Received " << KEEP_ALIVE_PING << ", responding with " << KEEP_ALIVE_OK << endl;
            if (!send_message(sock, KEEP_ALIVE_OK)) {
                if (debug_mode) cout << "[DEBUG] Failed to respond to keep-alive" << endl;
                connection_active = false;
                break;
            }
        } else {
            lock_guard<mutex> guard(q_mutex);
            msg_queue.push_back(server_msg);
            if (debug_mode) cout << "[DEBUG] Added message to queue (size: " << msg_queue.size() << ")" << endl;
        }

        // Check for server timeout
        auto now = chrono::steady_clock::now();
        auto time_since_activity = chrono::duration_cast<chrono::seconds>(now - last_server_activity).count();
        
        if (time_since_activity >= SERVER_TIMEOUT) {
            if (debug_mode) cout << "[DEBUG] Server timeout after " << time_since_activity << " seconds" << endl;
            connection_active = false;
            break;
        }
    }
    if (debug_mode) cout << "[DEBUG] Network listener thread ending" << endl;
}

// Main function
int main() {
    cout << "Quiz Game Client - Cache-Aware with Auto Mode" << endl;
    // cout << "Features:" << endl;
    // cout << "- Custom keep-alive protocol: KEEP_ALIVE <-> ALIVE_OK" << endl;
    // cout << "- CLI-based interface for quiz interaction" << endl;
    // cout << "- Genre selection and real-time question streaming" << endl;
    // cout << "- Cache vs API source detection and display" << endl;
    // cout << "- Real-time leaderboard viewing for connected clients" << endl;
    // cout << "- Support for timed quiz sessions (5-minute limit)" << endl;
    // cout << "- Automatic mode for testing multiple clients" << endl;
    // cout << "- Connection management and session handling" << endl;
    
    cout << "\nConfiguration options:" << endl;
    cout << "Enter 'debug' to enable debug mode" << endl;
    cout << "Enter 'auto' to enable automatic testing mode" << endl;
    cout << "Or press Enter to continue in normal mode: ";
    
    string config_input;
    getline(cin, config_input);
    config_input = trim_whitespace(config_input);
    
    if (config_input == "debug") {
        debug_mode = true;
        cout << "Debug mode enabled.\n" << endl;
    } else if (config_input == "auto") {
        auto_mode = true;
        cout << "Automatic testing mode enabled.\n" << endl;
        cout << "Client will automatically provide random responses for testing.\n" << endl;
    }

    while (true) {
        cout << "\n" << string(60, '=') << endl;
        cout << "                QUIZ GAME CLIENT" << endl;
        cout << string(60, '=') << endl;
        cout << "CLI-based Quiz Interface with Cache Detection" << endl;
        cout << string(60, '-') << endl;
        cout << "1. Play Quiz (Connect and select genre)" << endl;
        cout << "2. View Leaderboard (Request scores from server)" << endl;
        cout << "3. Exit" << endl;
        cout << string(60, '=') << endl;
        
        if (auto_mode) {
            cout << "[AUTO MODE] Automatically selecting option 1..." << endl;
            // In auto mode, always play quiz for testing
        } else {
            cout << "Enter your choice [1-3]: ";
        }

        string choice;
        if (auto_mode) {
            choice = "1";
            this_thread::sleep_for(chrono::milliseconds(1000));
        } else {
            getline(cin, choice);
        }
        choice = trim_whitespace(choice);

        if (choice == "1" || choice == "2") {
            int sock = 0;
            struct sockaddr_in serv_addr;
            
            if (debug_mode) cout << "[DEBUG] Creating socket for connection..." << endl;
            if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
                cerr << "Error: Could not create socket" << endl; 
                continue; 
            }
            
            serv_addr.sin_family = AF_INET;
            serv_addr.sin_port = htons(PORT);
            
            // Server IP - adjust as needed for your setup
            const char* server_ip = "192.168.50.111";  // Change this to your server's IP
            if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) { 
                cerr << "Error: Invalid server address" << endl; 
                close(sock); 
                continue; 
            }
            
            cout << "\nEstablishing connection to " << server_ip << ":" << PORT << "..." << endl;
            if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) { 
                cerr << "Error: Could not connect to server." << endl;
                cerr << "Please ensure the server is running and accessible." << endl;
                close(sock); 
                continue; 
            }

            cout << "Connection established successfully!" << endl;
            if (debug_mode) cout << "[DEBUG] Connected to server" << endl;

            connection_active = true;
            vector<string> msg_queue;
            mutex q_mutex;
            thread listener_thread(network_listener, sock, ref(msg_queue), ref(q_mutex));

            // Send command to server
            if (choice == "1") {
                if (debug_mode) cout << "[DEBUG] Sending PLAY command" << endl;
                send_message(sock, "PLAY");
                cout << "\nInitiating quiz session..." << endl;
                cout << "Note: Server will stream questions to you in real-time." << endl;
                cout << "Time limit: 5 minutes once quiz starts." << endl;
                if (auto_mode) {
                    cout << "[AUTO MODE] Will provide random responses automatically." << endl;
                }
            } else {
                if (debug_mode) cout << "[DEBUG] Sending VIEW command" << endl;
                send_message(sock, "VIEW");
                cout << "\nRequesting leaderboard from server..." << endl;
            }
            
            bool waiting_for_input = false;
            bool quiz_active = false;
            int question_count = 0;
            string quiz_source = "UNKNOWN";
            auto last_message_time = chrono::steady_clock::now();
            const int MESSAGE_TIMEOUT = 150; // Extended timeout for cache operations
            
            // Main CLI message processing loop
            while (connection_active) {
                string msg_to_process;
                bool has_message = false;
                
                {
                    lock_guard<mutex> guard(q_mutex);
                    if (!msg_queue.empty()) {
                        msg_to_process = msg_queue.front();
                        msg_queue.erase(msg_queue.begin());
                        has_message = true;
                        last_message_time = chrono::steady_clock::now();
                    }
                }

                if (has_message) {
                    if (debug_mode) {
                        cout << "[DEBUG] Processing: " << msg_to_process.substr(0, 50) << "..." << endl;
                    }
                    
                    // Handle server full message
                    if (msg_to_process.find("Server full") != string::npos) {
                        cout << "\n" << string(50, '!') << endl;
                        cout << msg_to_process << endl;
                        cout << string(50, '!') << endl;
                        connection_active = false;
                        break;
                    }
                    
                    // NEW: Handle cache source information (CUSTOM PROTOCOL EXTENSION)
                    if (msg_to_process.find("QUIZ_SOURCE:") == 0) {
                        quiz_source = msg_to_process.substr(12); // Remove "QUIZ_SOURCE:" prefix
                        
                        cout << "\n" << string(60, '=') << endl;
                        cout << "             QUIZ PREPARATION" << endl;
                        cout << string(60, '=') << endl;
                        cout << "Questions Source: ";
                        if (quiz_source == "CACHE") {
                            cout << "CACHE (Previously Generated)" << endl;
                            cout << "✓ Cache Hit - Questions served from server cache" << endl;
                            cout << "✓ Faster response time" << endl;
                            cout << "✓ Consistent question quality" << endl;
                            cout << "Status: Ready to start immediately!" << endl;
                        } else if (quiz_source == "API") {
                            cout << "API (Fresh Generation)" << endl;
                            cout << "⚡ Cache Miss - Generating new questions via LLM API" << endl;
                            cout << "⚡ Unique questions just for you" << endl;
                            cout << "⚡ May take longer due to API processing" << endl;
                            cout << "Status: Please wait, generating questions..." << endl;
                            cout << "This may take up to 2 minutes..." << endl;
                        }
                        cout << string(60, '=') << endl << endl;
                        continue;
                    }
                    
                    // Handle quiz session started message
                    if (msg_to_process.find("Quiz Session Started") != string::npos) {
                        cout << "\n" << string(50, '*') << endl;
                        cout << msg_to_process << endl;
                        cout << string(50, '*') << endl;
                        continue;
                    }
                    
                    // Handle timer-related messages
                    if (msg_to_process.find("TIME'S UP") != string::npos) {
                        cout << "\n" << string(50, '!') << endl;
                        cout << "TIME EXPIRED! Quiz session ended by server." << endl;
                        cout << string(50, '!') << endl;
                        cout << msg_to_process << endl;
                        continue;
                    }
                    
                    // Parse quiz source information (backward compatibility)
                    if (msg_to_process.find("API:") == 0 || msg_to_process.find("CACHE:") == 0) {
                        quiz_active = true;
                        question_count = 0;
                        
                        string source = msg_to_process.substr(0, msg_to_process.find(':'));
                        size_t colon_pos = msg_to_process.find(':');
                        if (colon_pos != string::npos) {
                            string count_str = msg_to_process.substr(colon_pos + 1);
                            
                            cout << "\n" << string(60, '=') << endl;
                            cout << "                   QUIZ STARTING" << endl;
                            cout << string(60, '=') << endl;
                            cout << "Questions Source: ";
                            if (source == "CACHE") {
                                cout << "CACHE (Previously Generated)" << endl;
                                cout << "✓ These questions were served from server cache" << endl;
                                cout << "✓ Cache hit - faster response time" << endl;
                            } else {
                                cout << "API (Freshly Generated)" << endl;
                                cout << "⚡ These questions were just created via LLM API" << endl;
                                cout << "⚡ Cache miss - new content generated" << endl;
                            }
                            cout << "Total Questions: " << count_str << endl;
                            cout << "Question Format: Multiple choice (A, B, C, D)" << endl;
                            cout << string(60, '=') << endl;
                            cout << "Get ready! First question coming up..." << endl;
                            cout << string(60, '=') << endl << endl;
                        }
                        continue;
                    }
                    
                    // Handle streamed questions (JSON format)
                    if (msg_to_process.front() == '{' && msg_to_process.find("question") != string::npos) {
                        try {
                            json q_data = json::parse(msg_to_process);
                            question_count++;
                            
                            cout << "\n" << string(70, '=') << endl;
                            cout << "Question " << question_count;
                            if (quiz_source != "UNKNOWN") {
                                cout << " (Source: " << quiz_source << ")";
                            }
                            cout << endl;
                            cout << string(70, '=') << endl;
                            cout << q_data["question"].get<string>() << endl;
                            cout << string(70, '-') << endl;
                            
                            auto options = q_data["options"];
                            for (const auto& option : options) { 
                                cout << option.get<string>() << endl; 
                            }
                            cout << string(70, '=') << endl;
                            
                            if (auto_mode) {
                                // Automatic mode - provide random answer
                                char random_answer = get_random_answer();
                                cout << "[AUTO MODE] Automatically selecting: " << random_answer << endl;
                                this_thread::sleep_for(chrono::milliseconds(500));
                                
                                if (!send_message(sock, string(1, random_answer))) {
                                    cout << "Error: Failed to send response to server" << endl;
                                    connection_active = false;
                                    break;
                                }
                            } else {
                                cout << "Your answer [A/B/C/D]: ";
                                waiting_for_input = true;
                            }
                            
                        } catch (const exception& e) { 
                            cout << "Error: Could not parse question from server." << endl;
                            if (debug_mode) {
                                cout << "[DEBUG] Parse error: " << e.what() << endl;
                                cout << "[DEBUG] Raw data: " << msg_to_process << endl;
                            }
                        }
                    }
                    // Handle server text messages
                    else {
                        // CLI Interface - Handle different server prompts
                        if (msg_to_process.find("Enter your username") != string::npos) {
                            cout << "\n" << string(50, '-') << endl;
                            cout << "SERVER: " << msg_to_process << endl;
                            cout << string(50, '-') << endl;
                            
                            if (auto_mode) {
                                string random_username = get_random_username();
                                cout << "[AUTO MODE] Using username: " << random_username << endl;
                                this_thread::sleep_for(chrono::milliseconds(500));
                                
                                if (!send_message(sock, random_username)) {
                                    cout << "Error: Failed to send username to server" << endl;
                                    connection_active = false;
                                    break;
                                }
                            } else {
                                cout << "Username: ";
                                waiting_for_input = true;
                            }
                        } else if (msg_to_process.find("Enter quiz genre") != string::npos) {
                            cout << "\n" << string(50, '-') << endl;
                            cout << "SERVER: " << msg_to_process << endl;
                            cout << "Available genres: science, history, sports, technology, literature, geography, etc." << endl;
                            cout << string(50, '-') << endl;
                            
                            if (auto_mode) {
                                string random_genre = get_random_genre();
                                cout << "[AUTO MODE] Selecting genre: " << random_genre << endl;
                                this_thread::sleep_for(chrono::milliseconds(500));
                                
                                if (!send_message(sock, random_genre)) {
                                    cout << "Error: Failed to send genre to server" << endl;
                                    connection_active = false;
                                    break;
                                }
                            } else {
                                cout << "Select genre: ";
                                waiting_for_input = true;
                            }
                        } else if (msg_to_process.find("Generating quiz") != string::npos) {
                            cout << "\n" << string(50, '*') << endl;
                            cout << msg_to_process << endl;
                            if (quiz_source == "API") {
                                cout << "Note: Generating fresh questions via LLM API..." << endl;
                                cout << "This may take longer than cached questions." << endl;
                            } else if (quiz_source == "CACHE") {
                                cout << "Note: Retrieving questions from server cache..." << endl;
                                cout << "This should be faster than API generation." << endl;
                            }
                            cout << string(50, '*') << endl;
                        } else if (msg_to_process.find("Correct!") != string::npos) {
                            cout << "\n✓ " << msg_to_process << " Well done!" << endl << endl;
                        } else if (msg_to_process.find("Wrong!") != string::npos) {
                            cout << "\n✗ " << msg_to_process << endl << endl;
                        } else {
                            cout << msg_to_process << endl;
                        }
                        
                        // Check for session end conditions
                        if (msg_to_process.find("LEADERBOARD") != string::npos ||
                            msg_to_process.find("Quiz over - final scores available") != string::npos ||
                            msg_to_process.find("Thanks for playing") != string::npos ||
                            msg_to_process.find("Connection will close") != string::npos ||
                            msg_to_process.find("Press Enter to return to menu") != string::npos ||
                            msg_to_process.find("Error:") != string::npos) {
                            
                            // Allow time for any remaining messages
                            this_thread::sleep_for(chrono::milliseconds(500));
                            
                            // Process any remaining messages in queue
                            {
                                lock_guard<mutex> guard(q_mutex);
                                while (!msg_queue.empty()) {
                                    cout << msg_queue.front() << endl;
                                    msg_queue.erase(msg_queue.begin());
                                }
                            }
                            
                            if (debug_mode) cout << "[DEBUG] Session end detected" << endl;
                            connection_active = false;
                            break;
                        }
                    }
                    
                    // CLI Input Handling (only in manual mode)
                    if (waiting_for_input && !auto_mode) {
                        string user_input;
                        getline(cin, user_input);
                        user_input = trim_whitespace(user_input);
                        
                        if (!connection_active) {
                            if (debug_mode) cout << "[DEBUG] Connection lost during input" << endl;
                            break;
                        }
                        
                        if (debug_mode) cout << "[DEBUG] Sending user input: " << user_input << endl;
                        
                        if (!send_message(sock, user_input)) {
                            cout << "Error: Failed to send response to server" << endl;
                            connection_active = false;
                            break;
                        }
                        
                        waiting_for_input = false;
                        
                        // Show feedback for quiz answers
                        if (quiz_active && user_input.length() == 1 && 
                            (toupper(user_input[0]) >= 'A' && toupper(user_input[0]) <= 'D')) {
                            cout << "Answer sent to server. Waiting for evaluation..." << endl;
                        }
                    }
                } else {
                    // No messages - brief pause
                    this_thread::sleep_for(chrono::milliseconds(100));
                    
                    // Check for message timeout
                    auto now = chrono::steady_clock::now();
                    auto time_since_message = chrono::duration_cast<chrono::seconds>(now - last_message_time).count();
                    
                    if (time_since_message > MESSAGE_TIMEOUT && connection_active && !waiting_for_input) {
                        if (debug_mode) cout << "[DEBUG] Message timeout - no server response" << endl;
                        cout << "No response from server. Connection may have been lost." << endl;
                        connection_active = false;
                    }
                }
            }

            if (debug_mode) cout << "[DEBUG] Waiting for network listener to finish..." << endl;
            if (listener_thread.joinable()) {
                listener_thread.join();
            }
            close(sock);
            if (debug_mode) cout << "[DEBUG] Connection closed" << endl;
            
            // CLI pause before returning to menu
            cout << "\nConnection ended." << endl;
            if (choice == "2") {
                if (auto_mode) {
                    this_thread::sleep_for(chrono::milliseconds(1000));
                } else {
                    cout << "Press Enter to return to main menu...";
                    cin.get();
                }
            } else {
                if (auto_mode) {
                    cout << "[AUTO MODE] Returning to menu for next test..." << endl;
                    this_thread::sleep_for(chrono::milliseconds(2000));
                } else {
                    cout << "Returning to main menu in 2 seconds..." << endl;
                    this_thread::sleep_for(chrono::milliseconds(2000));
                }
            }

        } else if (choice == "3") {
            cout << "\nExiting Quiz Game Client. Goodbye!" << endl;
            break;
        } else {
            if (!auto_mode) {
                cout << "Invalid choice. Please enter 1, 2, or 3." << endl;
            }
        }
        
        // In auto mode, add some delay between connections for testing
        if (auto_mode) {
            cout << "\n[AUTO MODE] Waiting before next connection..." << endl;
            this_thread::sleep_for(chrono::milliseconds(3000));
        }
    }
    return 0;
}