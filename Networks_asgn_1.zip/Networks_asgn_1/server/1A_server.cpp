#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <mutex>
#include <thread>
#include <atomic>
#include <cstring>
#include <cerrno>
#include <cctype>
#include <chrono>
#include <iomanip>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <map>
#include <unordered_map>
#include "json.hpp"

using namespace std;
using json = nlohmann::json;

// Configuration
const int SERVER_PORT = 11054;
const int BUFFER_SIZE = 8192;
const string LEADERBOARD_FILE = "leaderboard.txt";
const string API_IP = "192.168.50.142";
const int API_PORT = 25000;
const string ROLL_NO = "cs23btech11054";

// Quiz session settings - 5-minute timer as per requirements
const int QUIZ_TIME_LIMIT_MINUTES = 5;
const int QUIZ_TIME_LIMIT_SECONDS = QUIZ_TIME_LIMIT_MINUTES * 60;

// Keep-alive settings as per requirements (5s intervals, 5s timeout)
const int PING_INTERVAL_S = 5;
const int CLIENT_TIMEOUT_S = 5;
const string KEEP_ALIVE_PING = "KEEP_ALIVE";
const string KEEP_ALIVE_OK = "ALIVE_OK";

// Maximum client limit as per requirements
const int MAX_CLIENTS = 10;

// Global state
atomic<int> player_counter(0);
atomic<int> active_client_count(0);
atomic<bool> debug_mode(false);

enum ClientState {
    WAITING_FOR_COMMAND,
    WAITING_FOR_USERNAME,
    WAITING_FOR_GENRE,
    IN_QUIZ,
    QUIZ_OVER
};

struct ScoreEntry {
    string username;
    int score;
    int total;
    bool operator<(const ScoreEntry& other) const {
        if (score != other.score) return score > other.score;
        return total < other.total;
    }
};

struct QuizQuestion {
    string question_text;
    vector<string> options;
    char correct_answer_letter;
};

struct ActiveClient {
    int socket;
    int player_id;
    string client_ip;
    int client_port;
    string username;
    string genre;
    int score;
    int questions_answered;
    int total_questions;
    ClientState state;
    chrono::steady_clock::time_point quiz_start_time;
    chrono::steady_clock::time_point last_activity;
    bool quiz_completed;

    ActiveClient() : socket(-1), player_id(0), client_port(0), score(0), questions_answered(0),
                    total_questions(0), state(WAITING_FOR_COMMAND), quiz_completed(false) {}
};

// Global variables
mutex leaderboard_mutex;
mutex active_clients_mutex;
unordered_map<int, ActiveClient> active_clients;

// Function declarations
string trim(const string& str);
vector<QuizQuestion> parse_quiz_content(const string& content);
vector<QuizQuestion> parse_text_quiz(const string& content);
vector<ScoreEntry> get_leaderboard();
void add_score(const string& username, int score, int total);
string parseHttpResponse(const string& http_response);
bool reserveInstanceSocket();
string fetchQuizFromAPI_Socket(const string& genre);
void handle_client(int client_socket, struct sockaddr_in client_addr);
bool send_message(int sock, const string& msg);
bool receive_message(int sock, string& msg);
string get_realtime_leaderboard();
void cleanup_client(int client_socket);
string get_client_ip_port(const struct sockaddr_in& addr);
bool is_quiz_time_expired(const chrono::steady_clock::time_point& start_time);

// Quiz time management
bool is_quiz_time_expired(const chrono::steady_clock::time_point& start_time) {
    auto now = chrono::steady_clock::now();
    auto elapsed = chrono::duration_cast<chrono::seconds>(now - start_time).count();
    return elapsed >= QUIZ_TIME_LIMIT_SECONDS;
}

// Utility functions
string get_client_ip_port(const struct sockaddr_in& addr) {
    char ip_str[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(addr.sin_addr), ip_str, INET_ADDRSTRLEN);
    return string(ip_str) + ":" + to_string(ntohs(addr.sin_port));
}

void cleanup_client(int client_socket) {
    lock_guard<mutex> guard(active_clients_mutex);
    auto it = active_clients.find(client_socket);
    if (it != active_clients.end()) {
        active_clients.erase(it);
        active_client_count--;
    }
}

// Network functions
bool send_message(int sock, const string& msg) {
    uint32_t len = msg.length();
    uint32_t network_len = htonl(len);
    if (send(sock, &network_len, sizeof(network_len), MSG_NOSIGNAL) < 0) return false;
    if (send(sock, msg.c_str(), len, MSG_NOSIGNAL) < 0) return false;
    return true;
}

bool receive_message(int sock, string& msg) {
    uint32_t network_len;
    int bytes_read = recv(sock, &network_len, sizeof(network_len), 0);
    if (bytes_read <= 0) return false;
    if (bytes_read != sizeof(network_len)) return false;

    uint32_t len = ntohl(network_len);
    if (len > BUFFER_SIZE) return false;

    char buffer[BUFFER_SIZE] = {0};
    size_t total_bytes_read = 0;
    while (total_bytes_read < len) {
        bytes_read = recv(sock, buffer + total_bytes_read, len - total_bytes_read, 0);
        if (bytes_read <= 0) return false;
        total_bytes_read += bytes_read;
    }
    msg.assign(buffer, len);
    return true;
}

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r");
    if (string::npos == first) return "";
    size_t last = str.find_last_not_of(" \t\n\r");
    return str.substr(first, (last - first + 1));
}

// Real-time leaderboard for connected clients
string get_realtime_leaderboard() {
    lock_guard<mutex> guard(active_clients_mutex);

    vector<ActiveClient> quiz_clients;
    for (const auto& pair : active_clients) {
        const ActiveClient& client = pair.second;
        if (client.state == IN_QUIZ || client.quiz_completed) {
            quiz_clients.push_back(client);
        }
    }

    sort(quiz_clients.begin(), quiz_clients.end(), [](const ActiveClient& a, const ActiveClient& b) {
        if (a.score != b.score) return a.score > b.score;
        return a.questions_answered > b.questions_answered;
    });

    stringstream ss;
    ss << "\n=== REAL-TIME LEADERBOARD (Connected Clients) ===\n";
    ss << "Rank  Username        Score    Status\n";
    ss << "-------------------------------------------\n";

    if (quiz_clients.empty()) {
        ss << "No active quiz sessions\n";
    } else {
        int rank = 1;
        for (const auto& client : quiz_clients) {
            string status = client.quiz_completed ? "Completed" :
                           ("Q" + to_string(client.questions_answered + 1));

            ss << setw(2) << rank++ << ".   "
               << setw(12) << left << client.username
               << setw(9) << right << (to_string(client.score) + "/" + to_string(client.total_questions))
               << "  " << status << "\n";

            if (rank > 10) break;
        }
    }
    ss << "-------------------------------------------\n";

    return ss.str();
}

// Quiz parsing functions
vector<QuizQuestion> parse_quiz_content(const string& content) {
    vector<QuizQuestion> quiz;

    try {
        json data = json::parse(content);

        if (data.contains("choices") && data["choices"].size() > 0) {
            string inner_content = data["choices"][0]["message"]["content"];
            try {
                json inner_data = json::parse(inner_content);
                if (inner_data.contains("questions")) {
                    data = inner_data;
                }
            } catch (...) {
                return parse_text_quiz(inner_content);
            }
        }

        if (data.contains("questions") && data["questions"].is_array()) {
            int count = 0;
            for (const auto& item : data["questions"]) {
                if (count >= 10) break;

                QuizQuestion q;
                if (item.contains("q") && item.contains("options") && item.contains("a")) {
                    q.question_text = item["q"].get<string>();

                    auto options_array = item["options"];
                    for (const auto& opt : options_array) {
                        q.options.push_back(opt.get<string>());
                    }

                    if (q.options.size() == 4) {
                        string answer_str = item["a"].get<string>();
                        if (!answer_str.empty()) {
                            q.correct_answer_letter = toupper(answer_str[0]);
                            if (q.correct_answer_letter >= 'A' && q.correct_answer_letter <= 'D') {
                                quiz.push_back(q);
                                count++;
                            }
                        }
                    }
                }
            }
        }

    } catch (const exception& e) {
        return parse_text_quiz(content);
    }

    return quiz;
}

vector<QuizQuestion> parse_text_quiz(const string& content) {
    vector<QuizQuestion> quiz;
    istringstream ss(content);
    string line;
    QuizQuestion current_q;
    bool in_question = false;
    int question_count = 0;

    while (getline(ss, line) && question_count < 10) {
        line = trim(line);
        if (line.empty()) continue;

        if (line.length() > 2 && isdigit(line[0]) && line[1] == '.') {
            if (in_question && !current_q.question_text.empty() &&
                current_q.options.size() == 4 && current_q.correct_answer_letter != '\0') {
                quiz.push_back(current_q);
                question_count++;
            }

            if (question_count >= 10) break;

            current_q = QuizQuestion();
            current_q.question_text = trim(line.substr(2));
            current_q.options.clear();
            current_q.correct_answer_letter = '\0';
            in_question = true;
        }
        else if (in_question && line.length() > 2 &&
                 line[0] >= 'A' && line[0] <= 'D' && line[1] == ')') {
            if (current_q.options.size() < 4) {
                current_q.options.push_back(line);
            }
        }
        else if (in_question && (line.find("Answer:") == 0 || line.find("Correct:") == 0)) {
            size_t pos = line.find_first_of("ABCDabcd");
            if (pos != string::npos) {
                current_q.correct_answer_letter = toupper(line[pos]);
            }
        }
    }

    if (in_question && !current_q.question_text.empty() &&
        current_q.options.size() == 4 && current_q.correct_answer_letter != '\0' && question_count < 10) {
        quiz.push_back(current_q);
    }

    return quiz;
}

// Leaderboard functions
vector<ScoreEntry> get_leaderboard() {
    lock_guard<mutex> guard(leaderboard_mutex);
    vector<ScoreEntry> scores;
    ifstream file(LEADERBOARD_FILE);

    if (!file.is_open()) {
        return scores;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        ScoreEntry entry;
        if (ss >> entry.username >> entry.score >> entry.total) {
            scores.push_back(entry);
        }
    }
    file.close();
    sort(scores.begin(), scores.end());

    return scores;
}

void add_score(const string& username, int score, int total) {
    lock_guard<mutex> guard(leaderboard_mutex);
    ofstream file(LEADERBOARD_FILE, ios::app);
    if (file.is_open()) {
        file << username << " " << score << " " << total << endl;
        file.close();
    }
}

// API functions
string parseHttpResponse(const string& http_response) {
    size_t body_start = http_response.find("\r\n\r\n");
    if (body_start != string::npos) {
        return http_response.substr(body_start + 4);
    }
    return "";
}

bool reserveInstanceSocket() {
    int api_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (api_sock < 0) return false;

    struct timeval timeout;
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;
    setsockopt(api_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    struct sockaddr_in api_serv_addr;
    api_serv_addr.sin_family = AF_INET;
    api_serv_addr.sin_port = htons(API_PORT);
    inet_pton(AF_INET, API_IP.c_str(), &api_serv_addr.sin_addr);

    if (connect(api_sock, (struct sockaddr *)&api_serv_addr, sizeof(api_serv_addr)) < 0) {
        close(api_sock);
        return false;
    }

    string json_body = "{\"rollno\": \"" + ROLL_NO + "\"}";
    string http_request =
        "POST /reserve HTTP/1.1\r\n"
        "Host: " + API_IP + ":" + to_string(API_PORT) + "\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: " + to_string(json_body.length()) + "\r\n"
        "\r\n" + json_body;

    send(api_sock, http_request.c_str(), http_request.length(), 0);

    char buffer[BUFFER_SIZE];
    int bytes_read = recv(api_sock, buffer, BUFFER_SIZE - 1, 0);
    close(api_sock);

    if (bytes_read > 0) {
        buffer[bytes_read] = '\0';
        return string(buffer).find("200 OK") != string::npos;
    }
    return false;
}

string fetchQuizFromAPI_Socket(const string& genre) {
    int api_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (api_sock < 0) return "{\"error\": \"Socket creation failed\"}";

    struct timeval timeout;
    timeout.tv_sec = 45;
    timeout.tv_usec = 0;
    setsockopt(api_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    struct sockaddr_in api_serv_addr;
    api_serv_addr.sin_family = AF_INET;
    api_serv_addr.sin_port = htons(API_PORT);
    inet_pton(AF_INET, API_IP.c_str(), &api_serv_addr.sin_addr);

    if (connect(api_sock, (struct sockaddr *)&api_serv_addr, sizeof(api_serv_addr)) < 0) {
        close(api_sock);
        return "{\"error\": \"Connection failed\"}";
    }

    string json_body =
        "{\"rollno\": \"" + ROLL_NO + "\", "
        "\"messages\": ["
        "    {\"role\": \"system\", \"content\": \"Generate exactly 10 multiple-choice questions. Return ONLY valid JSON: {\\\"questions\\\":[{\\\"q\\\":\\\"Question?\\\",\\\"options\\\":[\\\"A) Option1\\\",\\\"B) Option2\\\",\\\"C) Option3\\\",\\\"D) Option4\\\"],\\\"a\\\":\\\"A\\\"},...]}.\"},"
        "    {\"role\": \"user\", \"content\": \"Generate 10 multiple-choice trivia questions about " + genre + ".\"}"
        "],"
        "\"temperature\": 0.1, "
        "\"max_tokens\": 3000}";

    string http_request =
        "POST /generate_quiz HTTP/1.1\r\n"
        "Host: " + API_IP + ":" + to_string(API_PORT) + "\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: " + to_string(json_body.length()) + "\r\n"
        "\r\n" + json_body;

    send(api_sock, http_request.c_str(), http_request.length(), 0);

    string http_response;
    char buffer[BUFFER_SIZE];
    int bytes_read;

    while ((bytes_read = recv(api_sock, buffer, BUFFER_SIZE - 1, 0)) > 0) {
        buffer[bytes_read] = '\0';
        http_response += buffer;

        if (http_response.find("\r\n\r\n") != string::npos) {
            size_t cl_pos = http_response.find("Content-Length:");
            if (cl_pos != string::npos) {
                size_t cl_end = http_response.find("\r\n", cl_pos);
                if (cl_end != string::npos) {
                    try {
                        string cl_str = http_response.substr(cl_pos + 15, cl_end - cl_pos - 15);
                        int content_length = stoi(trim(cl_str));
                        size_t body_start = http_response.find("\r\n\r\n") + 4;
                        if (http_response.length() - body_start >= content_length) {
                            break;
                        }
                    } catch (...) {
                        continue;
                    }
                }
            }
        }
    }

    close(api_sock);
    return parseHttpResponse(http_response);
}

// MAIN CLIENT HANDLER - Updated for full requirements compliance
void handle_client(int client_socket, struct sockaddr_in client_addr) {
    int player_id = ++player_counter;
    string client_ip_port = get_client_ip_port(client_addr);

    // Log client connection with IP address as required
    cout << "Client " << client_ip_port << " connected (Player " << player_id << ")" << endl;

    auto last_activity = chrono::steady_clock::now();
    bool ping_sent = false;
    chrono::steady_clock::time_point ping_sent_time;

    // Initialize client info
    ActiveClient client_info;
    client_info.socket = client_socket;
    client_info.player_id = player_id;
    client_info.client_ip = inet_ntoa(client_addr.sin_addr);
    client_info.client_port = ntohs(client_addr.sin_port);
    client_info.last_activity = last_activity;

    {
        lock_guard<mutex> guard(active_clients_mutex);
        active_clients[client_socket] = client_info;
    }

    ClientState state = WAITING_FOR_COMMAND;
    string username, genre;
    vector<QuizQuestion> quiz;
    int question_index = 0, score = 0;
    chrono::steady_clock::time_point quiz_start_time;

    while (true) {
        // Check quiz time limit
        if (state == IN_QUIZ && is_quiz_time_expired(quiz_start_time)) {
            add_score(username, score, quiz.size());
            cout << "Client " << client_ip_port << " quiz timed out after " << QUIZ_TIME_LIMIT_MINUTES << " minutes" << endl;
            
            stringstream timeout_msg;
            timeout_msg << "\nTIME'S UP! Quiz session ended after " << QUIZ_TIME_LIMIT_MINUTES << " minutes.\n";
            timeout_msg << "Your final score: " << score << "/" << question_index << " questions answered\n";
            timeout_msg << "\nQuiz over - final scores available\n";
            timeout_msg << get_realtime_leaderboard();
            timeout_msg << "\nConnection will close. Thanks for playing!\n";
            
            send_message(client_socket, timeout_msg.str());
            
            // Update client info
            {
                lock_guard<mutex> guard(active_clients_mutex);
                if (active_clients.find(client_socket) != active_clients.end()) {
                    active_clients[client_socket].quiz_completed = true;
                    active_clients[client_socket].score = score;
                    active_clients[client_socket].questions_answered = question_index;
                }
            }
            
            break;
        }

        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(client_socket, &read_fds);

        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        int activity = select(client_socket + 1, &read_fds, NULL, NULL, &timeout);

        if (activity < 0) break;

        if (activity > 0 && FD_ISSET(client_socket, &read_fds)) {
            string message;
            if (!receive_message(client_socket, message)) {
                cout << "Client " << client_ip_port << " disconnected (Player " << player_id << ")" << endl;
                break;
            }

            last_activity = chrono::steady_clock::now();

            // Handle keep-alive response
            if (message == KEEP_ALIVE_OK) {
                ping_sent = false;
                if (debug_mode) cout << "Client " << client_ip_port << " responded to keep-alive" << endl;
                continue;
            }

            // Update client activity
            {
                lock_guard<mutex> guard(active_clients_mutex);
                if (active_clients.find(client_socket) != active_clients.end()) {
                    active_clients[client_socket].last_activity = last_activity;
                }
            }

            // Handle client messages based on state
            switch (state) {
                case WAITING_FOR_COMMAND:
                    if (message == "PLAY") {
                        send_message(client_socket, "Enter your username:");
                        state = WAITING_FOR_USERNAME;
                        cout << "Client " << client_ip_port << " started quiz session" << endl;
                    } else if (message == "VIEW") {
                        cout << "Client " << client_ip_port << " requested leaderboard" << endl;

                        stringstream combined_board;
                        combined_board << get_realtime_leaderboard();

                        vector<ScoreEntry> historical = get_leaderboard();
                        if (!historical.empty()) {
                            combined_board << "\n=== HISTORICAL LEADERBOARD ===\n";
                            combined_board << "Rank  Username        Score\n";
                            combined_board << "----------------------------\n";
                            int rank = 1;
                            for (const auto& entry : historical) {
                                combined_board << setw(2) << rank++ << ".   "
                                             << setw(12) << left << entry.username
                                             << setw(6) << right << entry.score << "/" << entry.total << "\n";
                                if (rank > 10) break;
                            }
                            combined_board << "----------------------------\n";
                        }

                        combined_board << "Press Enter to return to menu...\n";
                        send_message(client_socket, combined_board.str());
                        usleep(500000);
                        goto cleanup;
                    }
                    break;

                case WAITING_FOR_USERNAME:
                    username = trim(message);
                    cout << "Client " << client_ip_port << " username: " << username << endl;

                    {
                        lock_guard<mutex> guard(active_clients_mutex);
                        if (active_clients.find(client_socket) != active_clients.end()) {
                            active_clients[client_socket].username = username;
                            active_clients[client_socket].state = WAITING_FOR_GENRE;
                        }
                    }

                    send_message(client_socket, "Enter quiz genre:");
                    state = WAITING_FOR_GENRE;
                    break;

                case WAITING_FOR_GENRE:
                    genre = trim(message);
                    cout << "Client " << client_ip_port << " selected genre: " << genre << endl;

                    if (!reserveInstanceSocket()) {
                        send_message(client_socket, "Error: Could not reserve API instance");
                        goto cleanup;
                    }

                    cout << "Generating quiz for client " << client_ip_port << " (genre: " << genre << ")" << endl;
                    send_message(client_socket, "Generating quiz, please wait...");

                    {
                        string quiz_response = fetchQuizFromAPI_Socket(genre);

                        if (quiz_response.find("error") != string::npos) {
                            cout << "Quiz generation failed for client " << client_ip_port << endl;
                            send_message(client_socket, "Error: Could not generate quiz. Please try again.");
                            goto cleanup;
                        }

                        quiz = parse_quiz_content(quiz_response);

                        if (quiz.empty()) {
                            cout << "No valid questions generated for client " << client_ip_port << endl;
                            send_message(client_socket, "Error: Could not generate valid questions. Please try a different genre.");
                            goto cleanup;
                        }

                        cout << "Quiz ready for client " << client_ip_port << " (" << quiz.size() << " questions)" << endl;

                        // Start quiz session with timer
                        quiz_start_time = chrono::steady_clock::now();

                        // Update client info
                        {
                            lock_guard<mutex> guard(active_clients_mutex);
                            if (active_clients.find(client_socket) != active_clients.end()) {
                                active_clients[client_socket].genre = genre;
                                active_clients[client_socket].state = IN_QUIZ;
                                active_clients[client_socket].total_questions = quiz.size();
                                active_clients[client_socket].quiz_start_time = quiz_start_time;
                            }
                        }

                        // Send quiz start message with timer info
                        stringstream start_msg;
                        start_msg << "\nQuiz Session Started!\n";
                        start_msg << "Time limit: " << QUIZ_TIME_LIMIT_MINUTES << " minutes\n";
                        start_msg << "Questions: " << quiz.size() << "\n";
                        start_msg << "Genre: " << genre << "\n\n";
                        start_msg << "Good luck!\n";

                        send_message(client_socket, start_msg.str());
                        usleep(200000);

                        // Send quiz source info (required by client)
                        send_message(client_socket, "API:" + to_string(quiz.size()));
                        usleep(200000);

                        // Send first question (streaming)
                        json q_json;
                        q_json["question"] = quiz[0].question_text;
                        q_json["options"] = quiz[0].options;
                        send_message(client_socket, q_json.dump());

                        state = IN_QUIZ;
                        question_index = 0;
                    }
                    break;

                case IN_QUIZ:
                    {
                        char answer = toupper(trim(message)[0]);
                        bool correct = (answer == quiz[question_index].correct_answer_letter);

                        if (correct) {
                            score++;
                            send_message(client_socket, "Correct!");
                            cout << "Client " << client_ip_port << " answered question " << (question_index + 1) << " correctly" << endl;
                        } else {
                            send_message(client_socket, "Wrong! Answer was " +
                                        string(1, quiz[question_index].correct_answer_letter));
                            cout << "Client " << client_ip_port << " answered question " << (question_index + 1) << " incorrectly" << endl;
                        }

                        question_index++;

                        // Update client progress in real-time
                        {
                            lock_guard<mutex> guard(active_clients_mutex);
                            if (active_clients.find(client_socket) != active_clients.end()) {
                                active_clients[client_socket].score = score;
                                active_clients[client_socket].questions_answered = question_index;
                            }
                        }

                        usleep(700000);

                        if (question_index < quiz.size()) {
                            // Stream next question
                            json q_json;
                            q_json["question"] = quiz[question_index].question_text;
                            q_json["options"] = quiz[question_index].options;
                            send_message(client_socket, q_json.dump());
                        } else {
                            // Quiz completed
                            add_score(username, score, quiz.size());
                            cout << "Client " << client_ip_port << " completed quiz. Final score: " << score << "/" << quiz.size() << endl;

                            {
                                lock_guard<mutex> guard(active_clients_mutex);
                                if (active_clients.find(client_socket) != active_clients.end()) {
                                    active_clients[client_socket].quiz_completed = true;
                                }
                            }

                            stringstream final_msg;
                            final_msg << "\nQuiz Complete! Your Final Score: " << score << "/" << quiz.size();
                            int percent = (score * 100) / quiz.size();
                            final_msg << " (" << percent << "%)\n";

                            if (percent >= 80) final_msg << "Excellent work!\n";
                            else if (percent >= 60) final_msg << "Good job!\n";
                            else final_msg << "Keep practicing!\n";

                            // Required message as per specifications
                            final_msg << "\nQuiz over - final scores available\n";
                            final_msg << get_realtime_leaderboard();
                            final_msg << "\nConnection will close. Thanks for playing!\n";

                            send_message(client_socket, final_msg.str());
                            usleep(500000);
                            goto cleanup;
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        // Keep-alive logic with exact timing requirements (5s intervals, 5s timeout)
        auto now = chrono::steady_clock::now();
        auto idle_time = chrono::duration_cast<chrono::seconds>(now - last_activity).count();

        if (ping_sent) {
            auto ping_time = chrono::duration_cast<chrono::seconds>(now - ping_sent_time).count();
            if (ping_time >= CLIENT_TIMEOUT_S) {
                cout << "Client " << client_ip_port << " failed to respond to keep-alive within " << CLIENT_TIMEOUT_S << " seconds - disconnecting" << endl;
                break;
            }
        }

        if (!ping_sent && idle_time >= PING_INTERVAL_S) {
            if (debug_mode) cout << "Sending keep-alive to client " << client_ip_port << endl;
            if (send_message(client_socket, KEEP_ALIVE_PING)) {
                ping_sent = true;
                ping_sent_time = now;
            } else {
                cout << "Failed to send keep-alive to client " << client_ip_port << " - disconnecting" << endl;
                break;
            }
        }
    }

cleanup:
    cleanup_client(client_socket);
    close(client_socket);
    cout << "Client " << client_ip_port << " session ended (Player " << player_id << ")" << endl;
}

int main() {
    cout << "Quiz Server" << endl;
    // cout << "Features implemented:" << endl;
    // cout << "- Maximum " << MAX_CLIENTS << " concurrent clients with multi-threading" << endl;
    // cout << "- " << QUIZ_TIME_LIMIT_MINUTES << "-minute quiz time limit per session" << endl;
    // cout << "- Keep-alive: " << PING_INTERVAL_S << "s intervals, " << CLIENT_TIMEOUT_S << "s timeout" << endl;
    // cout << "- IP address logging for all client connections" << endl;
    // cout << "- Custom protocol: KEEP_ALIVE <-> ALIVE_OK" << endl;
    // cout << "- Real-time question streaming to connected clients" << endl;
    // cout << "- Real-time and historical leaderboards" << endl;
    // cout << "- LLM API integration for quiz generation" << endl;
    // cout << "- Connection management and automatic session termination" << endl;
    cout << "\nDebug mode? (y/N): ";

    string input;
    getline(cin, input);
    if (input == "y" || input == "Y") {
        debug_mode = true;
        cout << "Debug mode enabled" << endl;
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(SERVER_PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        return 1;
    }

    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        return 1;
    }

    cout << "\nServer listening on port " << SERVER_PORT << endl;
    cout << "Maximum concurrent clients: " << MAX_CLIENTS << endl;
    cout << "Ready for connections..." << endl;

    while (true) {
        struct sockaddr_in client_addr;
        socklen_t client_addr_len = sizeof(client_addr);

        int client_socket = accept(server_fd, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        // Check maximum client limit
        if (active_client_count >= MAX_CLIENTS) {
            string client_ip_port = get_client_ip_port(client_addr);
            cout << "Client " << client_ip_port << " rejected - maximum clients (" << MAX_CLIENTS << ") reached" << endl;

            string reject_msg = "Server full. Maximum " + to_string(MAX_CLIENTS) + " clients allowed. Please try again later.";
            send_message(client_socket, reject_msg);
            close(client_socket);
            continue;
        }

        active_client_count++;
        thread(handle_client, client_socket, client_addr).detach();
    }

    close(server_fd);
    return 0;
}